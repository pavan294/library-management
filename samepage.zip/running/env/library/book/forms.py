from django import forms
from book.models import Student,Book

class StudentForm(forms.ModelForm):
    password = forms.CharField(max_length=32, widget=forms.PasswordInput)
    class Meta:
        model = Student
        exclude=('total_books_due',)
class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'
class BookUpdateForm(forms.ModelForm):
      class Meta:
        model = Book
        exclude=('total_copies','available_copies',)
      
