from django.contrib import admin

# Register your models here.
from book.models import Genre,Language,Book,Student,Borrower
admin.site.register(Genre)
admin.site.register(Language)
admin.site.register(Book)
admin.site.register(Student)
admin.site.register(Borrower)
