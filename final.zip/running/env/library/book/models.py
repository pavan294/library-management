from django.db import models

from django.db import models
#relation containg all genre of books
class Genre(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name



##relation containing language of books
class Language(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name

#book relation that has 2 foreign key author language
#book relation can contain multiple genre so we have used manytomanyfield
class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    summary = models.TextField(max_length=400, help_text="Enter a brief description of the book")
    version = models.CharField(max_length=13)
    genre = models.ManyToManyField(Genre, help_text="Select a genre for this book")
    language = models.ForeignKey('Language', on_delete=models.SET_NULL, null=True)
    total_copies = models.IntegerField()
    available_copies = models.IntegerField()
    def __str__(self):
        return self.title

#relation containing info about students
#roll_no is used for identifing students uniquely
class Student(models.Model):
    roll_no = models.CharField(max_length=10,unique=True)
    name = models.CharField(max_length=10)
    branch = models.CharField(max_length=3)
    contact_no = models.CharField(max_length=10)
    password = models.CharField(max_length=10,default="admin123")
    total_books_due=models.IntegerField(default=0)
    email=models.EmailField()
    def __str__(self):
        return str(self.roll_no)


#relation containing info about Borrowed books
#it has  foriegn key book and student for refrencing book nad student
#roll_no is used for identifing students
#if a book is returned than corresponding tuple is deleted from database
class Borrower(models.Model):
    student = models.ForeignKey('Student', on_delete=models.CASCADE)
    book = models.ForeignKey('Book', on_delete=models.CASCADE)
    issue_date = models.DateTimeField(null=True,blank=True)
    def __str__(self):
        return self.student.name+" borrowed "+self.book.title





