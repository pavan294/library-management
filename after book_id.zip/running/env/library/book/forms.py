from django import forms
from book.models import Student,Book,Borrower
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Submit

class StudentForm(forms.ModelForm):
    password = forms.CharField(max_length=32, widget=forms.PasswordInput)
    class Meta:
        model = Student
        exclude=('total_books_due',)
class BookForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(BookForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.fields['summary'].widget.attrs['style']  = 'height: 100px'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-success'))
    class Meta:
        model = Book
        fields = '__all__'
class BookUpdateForm(forms.ModelForm):
      def __init__(self, *args, **kwargs):
        super(BookUpdateForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()  
        self.helper.form_class = 'form-horizontal'
        self.helper.label_class = 'col-lg-2'
        self.helper.field_class = 'col-lg-8'
        self.fields['summary'].widget.attrs['style']  = 'height: 100px'
        self.helper.add_input(Submit('submit', 'Submit', css_class='btn-success'))
      class Meta:
        model = Book
        exclude=('title','total_copies','available_copies',)
class BorrowerForm(forms.ModelForm):
      class Meta:
        model = Borrower
        fields="__all__"